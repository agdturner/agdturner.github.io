# -*- coding: utf-8 -*-
"""
Created on Fri Nov 25 23:40:03 2022

@author: Andy Turner
"""
x = 1
if x == 1:
    y = 2
print(y)