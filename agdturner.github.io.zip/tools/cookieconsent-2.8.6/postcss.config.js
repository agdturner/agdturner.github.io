module.exports = {
    map: false,
    plugins: {
        'cssnano': {}
    }
}